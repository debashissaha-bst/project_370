from django.shortcuts import render, redirect
from .models import User, Book
from .forms import UserForm, BookForm

def home_view(request):
  if request.method == 'POST':
    user_form = UserForm(request.POST)
    book_form = BookForm(request.POST)
        
    if user_form.is_valid():
      user_form.save()
      return redirect('data_view')

    if book_form.is_valid():
      book_form.save()
      return redirect('data_view')
  else:
    user_form = UserForm()
    book_form = BookForm()

  return render(request, 'home.html', {
    'user_form': user_form,
    'book_form': book_form
  })

def data_view(request):
  users = User.objects.all()
  books = Book.objects.all()
  return render(request, 'data_view.html', {
    'users': users,
    'books': books
    })