from django import forms
from .models import User, Book

class UserForm(forms.ModelForm):
  class Meta:
    model = User
    fields = ['f_name', 'l_name', 'short_bio', 'birth_date', 'email']

class BookForm(forms.ModelForm):
  class Meta:
    model = Book
    fields = ['ISBN', 'book_name', 'author', 'description', 'publish_date', 'language']
