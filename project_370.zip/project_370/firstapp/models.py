from django.db import models

class User(models.Model):
  f_name = models.CharField(max_length=255)
  l_name = models.CharField(max_length=255)
  short_bio = models.CharField(max_length=255)
  birth_date = models.DateField(null=True)
  email = models.EmailField(unique=True)

class Book(models.Model):
  ISBN = models.CharField(max_length = 15, unique = True)
  book_name = models.CharField(max_length = 150)
  author = models.CharField(max_length = 150)
  description = models.TextField()
  publish_date = models.DateField()
  language = models.CharField(max_length=50)
